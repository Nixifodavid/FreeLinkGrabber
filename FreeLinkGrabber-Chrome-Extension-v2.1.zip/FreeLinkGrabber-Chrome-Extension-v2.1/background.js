chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== 'OPEN_URLS') return;

    const urls = Array.isArray(message.urls) ? message.urls : [];
    const clean = [...new Set(urls)].filter(u => /^https?:\/\//i.test(u));

    for (const url of clean) {
        chrome.tabs.create({ url, active: false });
    }

    sendResponse({ opened: clean.length });
    return true;
});
