# FreeLinkGrabber — Chrome Extension

Version 3.1

- Larger borderless supplied logo in the results window.
- Logo is embedded directly into the content script so it cannot appear as a broken image.
- Colorful logo treatment and extension icons.
- Select individual URLs.
- **Open Selected** opens checked URLs in new tabs.
- Copy Selected and Download TXT.
- Auto-scroll while selecting.
- Special thanks to **Lakshaydeep Verma**.

## Install
1. Extract the ZIP.
2. Open `chrome://extensions/`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `FreeLinkGrabber-extension` folder.

After updating, click **Reload** on FreeLinkGrabber if an older version is already installed.
