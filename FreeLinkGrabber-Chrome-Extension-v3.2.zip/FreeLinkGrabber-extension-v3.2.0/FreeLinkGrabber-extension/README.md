# FreeLinkGrabber 3.2.0

- Popup toggle turns the extension on or off.
- Ctrl + left-click toggles grab mode on the current page.
- Press Esc to close the results window or cancel an active selection.
- Keeps the existing area-selection, auto-scroll, URL selection, open/copy/download features.

## Install / update
1. Extract the ZIP.
2. Open `chrome://extensions/` and enable Developer mode.
3. Click **Load unpacked** and select this folder.
4. For an existing install, remove the old unpacked folder only if needed, then load this updated folder or use **Reload** and select the updated folder.
