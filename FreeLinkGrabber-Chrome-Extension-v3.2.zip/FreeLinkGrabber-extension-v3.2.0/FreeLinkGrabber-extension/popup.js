const button = document.getElementById('toggle');
const status = document.getElementById('status');
const statusText = document.getElementById('statusText');
function render(enabled) {
  status.classList.toggle('off', !enabled);
  statusText.textContent = enabled ? 'Enabled' : 'Disabled';
  button.textContent = enabled ? 'Turn Off Extension' : 'Turn On Extension';
  button.classList.toggle('off', !enabled);
}
chrome.storage.local.get({ extensionEnabled: true }, data => render(data.extensionEnabled !== false));
button.addEventListener('click', async () => {
  const data = await chrome.storage.local.get({ extensionEnabled: true });
  const enabled = data.extensionEnabled === false;
  await chrome.storage.local.set({ extensionEnabled: enabled });
  render(enabled);
});
